import sys
from PyQt5 import Qt
from PyQt5.QtGui import QIcon, QPixmap
from PyQt5.QtCore import pyqtSignal, QTimer, QTime, QSize
from PyQt5.QtWidgets import (QApplication, QMainWindow, QPushButton,
                             QDialog, QVBoxLayout)
import random
import sqlite3
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg
from main_menu import MainMenuUi
from difficulty import DifficultyUi
from help import HelpUi
from sapper_ui import SapperUi
from stats import StatsUi

NUM_COLORS = {1: '#3C24ED', 2: '#15C015', 3: '#FC8302',
              4: '#F70905', 5: '#900B09', 6: '#900B09',
              7: '#FA0782'}
WIN_COLORS = ['#1E81D2', '#E1321A', '#20B018',
              '#C425C1', '#FA022D', '#E5C22C',
              '#7B11B4', '#07C7E9', '#F2592E']


class MainMenu(QMainWindow, MainMenuUi):
    def __init__(self):
        super(MainMenu, self).__init__()
        self.setupUi(self)
        self.setWindowTitle('Главное меню')

        self.mine_label1.setPixmap(QPixmap('mine.png').scaledToWidth(100))
        self.mine_label2.setPixmap(QPixmap('mine.png').scaledToWidth(100))

        self.play_btn.clicked.connect(self.play)
        self.exit_btn.clicked.connect(self.exit)
        self.stats_btn.clicked.connect(self.open_stats)

    def play(self):
        choice = DifficultyChoice()
        choice.exec()
        if choice.value:
            self.close()
            if not choice.time_game:
                game = ClassicSapper(*choice.value)
            else:
                game = TimeSapper(*choice.value)
            game.exec()
            self.show()

    def open_stats(self):
        stats = Statistics()
        stats.exec()

    def exit(self):
        self.close()


class DifficultyChoice(QDialog, DifficultyUi):
    def __init__(self):
        super(DifficultyChoice, self).__init__()
        self.value = None
        self.time_game = False
        self.dic = {'Легко': (8, 8, 10, 1, True), 'Нормально': (16, 16, 40, 2, True),
                    'Сложно': (30, 16, 99, 3, True), 'Адские муки': (30, 16, 99, 4, False)}

        self.setupUi(self)
        self.setWindowTitle('Выбор сложности')
        self.buttonGroup.buttonClicked.connect(self.get_choice)
        self.time_btn.clicked.connect(self.start_time_game)
        self.help_btn.clicked.connect(self.show_help)

    def get_choice(self, btn):
        # Возвращает параметры выбранной сложности
        self.value = self.dic[btn.text()]
        self.close()

    def start_time_game(self):
        self.value = self.dic['Нормально']
        self.time_game = True
        self.close()

    def show_help(self):
        help = Help()
        help.exec()


class Statistics(QDialog, StatsUi):
    def __init__(self):
        super(Statistics, self).__init__()
        con = sqlite3.connect('sapper_stats')
        cur = con.cursor()
        self.stats = cur.execute('SELECT * FROM games').fetchall()

        self.setupUi(self)
        self.setWindowTitle('Статистика')

        if self.stats:
            self.init_stats()
            self.pps_show.clicked.connect(self.draw_graph)

    def init_stats(self):
        # Инициализириует необходимую инф-ю для статистики
        time = sum(game[2] for game in self.stats)
        cells_open = sum(game[3] for game in self.stats)
        cells_pushed = sum(game[4] for game in self.stats)
        wins = sum(game[5] for game in self.stats)
        points = list(game[6] for game in self.stats if game[6])
        max_points = max(points) if points else 0

        if self.stats:
            self.wins_count.setText(str(wins))
            self.time_count.setText(f'{time // 3600} ч {time % 3600 // 60} мин '
                                    f'{time % 3600 % 60} с')
            self.cells_count.setText(str(cells_open))
            self.duration_count.setText(f'{time // len(self.stats)} c')
            self.pps_count.setText(f'{cells_pushed / time:.3f}')
            self.max_points.setText(str(max_points))

    def draw_graph(self):
        graph = Graph()
        graph.exec()


class Graph(QDialog):
    # График эффективных нажатий
    def __init__(self):
        super(Graph, self).__init__()
        self.setWindowTitle('График')

        con = sqlite3.connect('sapper_stats')
        cur = con.cursor()
        self.stats = cur.execute('SELECT * FROM games').fetchall()

        fig = plt.figure()
        plt.plot(*self.get_coords())
        plt.grid(True)
        plt.xlabel('Кол-во игр')
        plt.ylabel('Нажатий / с')

        canvas = FigureCanvasQTAgg(fig)
        self.setLayout(QVBoxLayout(self))
        self.layout().addWidget(canvas)

    def get_coords(self):
        # Возвращает координаты для построения графика
        time = 0
        cells_pushed = 0
        xs = [i for i in range(len(self.stats))]
        ys = []
        for i in range(len(self.stats)):
            time += self.stats[i][2]
            cells_pushed += self.stats[i][4]
            y = cells_pushed / time
            ys.append(y)
        return xs, ys


class Help(QDialog, HelpUi):
    def __init__(self):
        super(Help, self).__init__()
        self.setupUi(self)
        self.setWindowTitle('Справка')


class Cell(QPushButton):
    left_click = pyqtSignal()
    right_click = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.btn_style = '''QPushButton:!hover { background-color: #C2BDBD } 
                            QPushButton:hover { background-color: #E3E0E0 } '''
        self.setStyleSheet(self.btn_style)
        self.flag = False

    def mousePressEvent(self, event):
        button = event.button()
        if button == Qt.Qt.RightButton:
            self.right_click.emit()
        elif button == Qt.Qt.LeftButton:
            self.left_click.emit()


class ClassicSapper(QDialog, SapperUi):
    def __init__(self, w, h, mines, difficulty, flags=True):
        super(ClassicSapper, self).__init__()
        self.w, self.h = w, h
        self.mines = mines
        self.flags = flags
        self.difficulty = difficulty

        self.setupUi(self)
        self.setWindowTitle('Сапер')
        self.setFixedSize(self.w * 50, self.h * 50 + 100)
        self.points_lcd.setVisible(False)

        self.timer = QTimer()

        self.restart()

        self.flag_icon = QIcon('flag.png')

        # Устанавливает иконки
        self.restart_btn.setIcon(QIcon('restart_icon.png'))
        self.restart_btn.setIconSize(QSize(50, 50))
        self.back_btn.setIcon(QIcon('back.png'))
        self.back_btn.setIconSize(QSize(30, 100))
        self.time_label.setPixmap(QPixmap('clock.png').scaledToWidth(40))
        self.mines_label.setPixmap(QPixmap('mine.png').scaledToWidth(40))

        self.back_btn.clicked.connect(self.to_menu)
        self.restart_btn.clicked.connect(self.restart)
        self.timer.timeout.connect(self.timer_event)

        self.con = sqlite3.connect('sapper_stats')
        self.cur = self.con.cursor()

    def initUI(self):
        for i in reversed(range(self.field_layout.count())):
            self.field_layout.itemAt(i).widget().setParent(None)

        self.mines_counter.display(self.mines_amount)

        #  Создание ячеек поля
        for row in range(self.h):
            for col in range(self.w):
                btn = Cell()
                btn.setFixedSize(50, 50)
                #  Обработка нажатия ЛКМ или ПКМ
                btn.left_click.connect(self.movement)
                btn.right_click.connect(self.set_flag)

                self.btn_to_index[btn] = (row, col)
                self.index_to_btn[(row, col)] = btn

                self.field_layout.addWidget(btn, row, col)

    def restart(self):
        self.first_turn = True
        self.btn_to_index = {}  # Словарь - Кнопка: индекс кнопки на поле
        self.index_to_btn = {}  # Словарь - Индекс кнопки на поле: кнопка

        self.mines_amount = self.mines
        self.cells_open = 0
        self.cells_pushed = 0
        self.field = Field(self.w, self.h, self.mines_amount)

        self.initUI()

        self.time = QTime(0, 0, 0)
        self.time_bar.display(0)
        self.timer.stop()

    def to_menu(self):
        self.close()

    def timer_event(self):
        self.time = self.time.addSecs(1)
        relevant_time = self.time.hour() * 3600 + self.time.minute() * 60 + self.time.second()
        self.time_bar.display(relevant_time)

    def movement(self):
        cell = self.sender()
        row, col = self.btn_to_index[cell]
        if self.first_turn:
            # Сгенерирует мины после 1 хода, шоб не подорваться сразу
            self.field.generate_mines(row, col)
            self.timer.start(1000)
            self.first_turn = False
        self.open_cell(cell)

    def open_cell(self, cell):
        row, col = self.btn_to_index[cell]
        if not cell.flag:
            if not self.field[row][col]:
                self.open_free_area(row, col)
                self.cells_pushed += 1
            elif self.field[row][col] == 'M':
                self.defeat()
            else:
                self.set_activated(cell)
                self.cells_pushed += 1
            self.win()

    def set_flag(self):
        cell = self.sender()
        if not self.first_turn and self.flags:
            if not cell.flag:
                cell.setIcon(self.flag_icon)
                cell.setIconSize(QSize(50, 50))
                cell.setStyleSheet('background-color: #C2BDBD')
                self.mines_amount -= 1
                cell.flag = True
            else:
                cell.setIcon(QIcon())
                cell.setStyleSheet(cell.btn_style)
                self.mines_amount += 1
                cell.flag = False
            self.mines_counter.display(self.mines_amount)
            self.win()

    def open_free_area(self, row, col):
        # Рекурсивно открывает пустые поля
        if not self.index_to_btn[(row, col)].flag:
            self.set_activated(self.index_to_btn[(row, col)])

        for i in range(-1, 2):
            for j in range(-1, 2):
                if ((self.is_free_area(row + i, col + j)) and
                        (self.index_to_btn[(row + i, col + j)].isEnabled())):
                    self.open_free_area(row + i, col + j)
        self.open_area_around(row, col)

    def open_area_around(self, row, col):
        # Показывает числа-посказки вокруг пустой клетки, если таковые есть
        for i in range(-1, 2):
            for j in range(-1, 2):
                if (self.field.not_outside_field(row + i, col + j) and
                        (self.field[row + i][col + j]) and
                        (self.index_to_btn[(row + i, col + j)].isEnabled()) and
                        (i or j)):
                    btn = self.index_to_btn[(row + i, col + j)]
                    btn.setIcon(QIcon())
                    btn.setText(str(self.field[row + i][col + j]))
                    self.set_activated(btn)

    def show_mines(self):
        # Показывает все мины на поле
        for row in range(self.h):
            for col in range(self.w):
                if self.field[row][col] == 'M':
                    cell = self.index_to_btn[(row, col)]
                    cell.setText('☼')
                    cell.setFlat(True)
                    cell.setStyleSheet('color: #8F0505; font: bold 20px')

    def set_activated(self, cell):
        # Срабатывает при нажатии на клетку, делает ее некликабельной
        row, col = self.btn_to_index[cell]
        value = self.field[row][col]
        if value:
            cell.setText(str(value))
            cell.setStyleSheet(f'color: {NUM_COLORS[value]}; font: bold 20px')
        cell.setFlat(True)
        cell.setDisabled(True)
        self.cells_open += 1

    def disable_all(self):
        # Блокирует все ячейки поля
        for row in range(self.h):
            for col in range(self.w):
                self.index_to_btn[(row, col)].setDisabled(True)
                self.index_to_btn[(row, col)].setIcon(QIcon())
        self.timer.stop()

    def is_free_area(self, row, col):
        # Проверяет нет ли в клетке чисел-подсказок
        return self.field.not_outside_field(row, col) and not self.field[row][col]

    def win(self):
        if ((self.cells_open == self.w * self.h - self.mines) and
                (not self.flags or self.mines_amount == 0)):
            self.show_mines()
            row, col = self.h // 2 - 1, (self.w - 4) // 2
            phrase = 'YOU WON'
            for i in range(3):
                btn1 = self.index_to_btn[row, col + i]
                btn1.setText(phrase[i])
                btn1.setStyleSheet(f'color: black; background-color: {random.choice(WIN_COLORS)};'
                                   'font: bold 20px;')
                btn1.setFlat(False)
                btn2 = self.index_to_btn[row + 1, col + i]
                btn2.setText(phrase[i + 4])
                btn2.setStyleSheet(f'color: black; background-color: {random.choice(WIN_COLORS)};'
                                   'font: bold 20px;')
                btn2.setFlat(False)
            self.disable_all()
            self.add_stat(1)

    def defeat(self):
        self.show_mines()
        self.disable_all()
        self.add_stat(0)

    def add_stat(self, win):
        if self.cells_pushed > 5:
            req = '''
            INSERT INTO games(difficulty, duration, cells_open, cells_pushed, win) VALUES
            (?, ?, ?, ?, ?) 
                  '''
            self.cur.execute(req, (self.difficulty,
                                   self.time.minute() * 60 + self.time.second(),
                                   self.cells_open,
                                   self.cells_pushed,
                                   win))
            self.cur.connection.commit()


class TimeSapper(ClassicSapper):
    # Сапер на время
    def __init__(self, w, h, mines, difficulty, flags=True):
        super(TimeSapper, self).__init__(w, h, mines, difficulty)
        self.restart()

    def restart(self):
        self.repaint_field()
        self.rounds = 1
        self.points = 0
        self.relevant_time = 0
        self.time_counter = 0
        self.points_lcd.display(0)

        self.time = QTime(0, 0, 58)
        self.time_bar.display(0)
        self.timer.stop()

    def repaint_field(self):
        super(TimeSapper, self).restart()
        self.points_lcd.setVisible(True)

    def timer_event(self):
        # Переопредляем на убывание времени
        self.time = self.time.addSecs(-1)
        self.time_counter += 1
        self.relevant_time = self.time.hour() * 3600 + self.time.minute() * 60 + self.time.second()
        self.time_bar.display(self.relevant_time)

        if self.relevant_time <= 0:
            self.defeat()

    def open_cell(self, cell):
        # Добавляет бонусное время и очки при успешном нажатии
        row, col = self.btn_to_index[cell]
        if not cell.flag:
            if not self.field[row][col]:
                self.open_free_area(row, col)
                self.cells_pushed += 1
                self.points += 2
                self.time = self.time.addSecs(2)
            elif self.field[row][col] == 'M':
                self.defeat()
            else:
                self.set_activated(cell)
                self.cells_pushed += 1
                self.points += 2
                self.time = self.time.addSecs(2)
            self.win()

            self.points_lcd.display(self.points)
            self.time_bar.display(self.relevant_time)

    def open_free_area(self, row, col):
        # Переоопределено на добавление очков
        if not self.index_to_btn[(row, col)].flag:
            self.set_activated(self.index_to_btn[(row, col)])

        for i in range(-1, 2):
            for j in range(-1, 2):
                if ((self.is_free_area(row + i, col + j)) and
                        (self.index_to_btn[(row + i, col + j)].isEnabled())):
                    self.open_free_area(row + i, col + j)
        self.open_area_around(row, col)
        self.points += 1

    def win(self):
        if ((self.cells_open == self.w * self.h - self.mines) and
                (not self.flags or self.mines_amount == 0)):
            self.rounds += 1
            self.points += 100
            self.add_stat(1)
            self.repaint_field()
            self.time = QTime(self.relevant_time // 3600,
                              self.relevant_time // 60,
                              self.relevant_time % 3600 % 60)

    def add_stat(self, win):
        if self.cells_pushed > 5 or self.rounds > 1:
            req = '''
            INSERT INTO games(difficulty, duration, cells_open, cells_pushed, win, points) VALUES
            (?, ?, ?, ?, ?, ?) 
                  '''
            self.cur.execute(req, (self.difficulty,
                                   self.time_counter,
                                   self.cells_open,
                                   self.cells_pushed,
                                   win,
                                   self.points))
            self.cur.connection.commit()


class Field:
    def __init__(self, w, h, mines):
        self.w, self.h = w, h
        self.mines = mines
        self.field = self.create_field()

    def __getitem__(self, key):
        return self.field[key]

    def create_field(self):
        return [[0 for col in range(self.w)] for row in range(self.h)]

    def generate_mines(self, row, col):
        # Генерирует мины на поле
        is_generated = False
        while not (is_generated and self.is_playable_generation()):
            # Пока поле неиграбельно будет переставлять мины в нем
            self.field = self.create_field()

            sequence = [i for i in range(self.w * self.h)
                        if i not in self.indexes_around(row, col)]
            indexes = random.sample(sequence, self.mines)

            # В indexes записываются номера ячеек, в которых находится мина
            for i in indexes:
                # Мины расставляются по полю
                self.field[i // self.w][i % self.w] = 'M'

            is_generated = True
        self.generate_numbers()

    def generate_numbers(self):
        # Генерирует числа-подсказки
        for row in range(self.h):
            for col in range(self.w):
                if self.field[row][col] != 'M':
                    self.field[row][col] = self.look_mines_around(row, col)

    def indexes_around(self, row, col):
        # Возвращает номера индексов вокруг
        indexes = set()
        for i in range(-1, 2):
            for j in range(-1, 2):
                if self.not_outside_field(row + i, col + j):
                    indexes.add((row + i) * self.w + col + j)
        return indexes

    def look_mines_around(self, row, col):
        # Подсчитывает кол-во мин вокруг клетки
        counter = 0
        for i in range(-1, 2):
            for j in range(-1, 2):
                if (self.not_outside_field(row + i, col + j) and
                        (self.field[row + i][col + j] == 'M')):
                    counter += 1
        return counter

    def is_playable_generation(self):
        # Проверяет, нет ли такого, что мины занимают всю строку или колонку целиком
        horizontally_playable = not any(
            [all([self.field[row][col] == 1 for col in range(self.w)])
             for row in range(self.h)])
        vertically_playable = not any(
            [all([self.field[row][col] == 1 for row in range(self.h)])
             for col in range(self.w)])

        return vertically_playable and horizontally_playable

    def not_outside_field(self, row, col):
        # Проверяет не выходит ли за границы поля
        return self.h > row >= 0 and self.w > col >= 0


def except_hook(cls, exception, traceback):
    sys.__excepthook__(cls, exception, traceback)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    sapper = MainMenu()
    sapper.show()
    sys.excepthook = except_hook
    sys.exit(app.exec())
